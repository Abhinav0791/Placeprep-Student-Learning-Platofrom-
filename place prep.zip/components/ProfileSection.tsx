"use client"

import { useState } from "react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Award, Calendar, Code, FileText, GraduationCap, LogOut, Settings, User } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"

export default function ProfileSection() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
      <DropdownMenuTrigger asChild>
        <div className="flex items-center gap-3 p-2 pr-4 rounded-full border border-primary/20 cursor-pointer hover:bg-gradient-to-r hover:from-primary/5 hover:to-purple-500/5 transition-all duration-300 group">
          <Avatar className="h-9 w-9 ring-2 ring-primary/20 group-hover:ring-primary/40 transition-all duration-300">
            <AvatarImage src="/placeholder.svg?height=36&width=36" alt="User" />
            <AvatarFallback className="bg-gradient-to-br from-primary/10 to-purple-500/10 text-primary font-semibold">
              US
            </AvatarFallback>
          </Avatar>
          <div className="hidden md:block text-left">
            <p className="text-sm font-semibold leading-none">Student User</p>
            <div className="flex items-center gap-1 mt-1">
              <Badge className="tier-2 text-xs px-2 py-0">Tier 2</Badge>
            </div>
          </div>
        </div>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80 glass-card border-0 shadow-xl">
        <div className="flex flex-col p-6 space-y-4">
          <div className="flex items-center gap-4">
            <Avatar className="h-16 w-16 ring-2 ring-primary/20">
              <AvatarImage src="/placeholder.svg?height=64&width=64" alt="User" />
              <AvatarFallback className="bg-gradient-to-br from-primary/10 to-purple-500/10 text-primary font-bold text-lg">
                US
              </AvatarFallback>
            </Avatar>
            <div>
              <p className="font-semibold text-lg">Student User</p>
              <p className="text-sm text-muted-foreground">student@example.com</p>
              <Badge className="tier-2 mt-1">Tier 2 Student</Badge>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span className="font-medium">Profile Completion</span>
              <span className="font-semibold text-primary">75%</span>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div className="progress-bar rounded-full h-2" style={{ width: "75%" }} />
            </div>
          </div>

          <div className="profile-stats">
            <div className="profile-stat-item">
              <span className="profile-stat-value">42</span>
              <span className="profile-stat-label">Problems</span>
            </div>
            <div className="profile-stat-item">
              <span className="profile-stat-value">3</span>
              <span className="profile-stat-label">Interviews</span>
            </div>
            <div className="profile-stat-item">
              <span className="profile-stat-value">8</span>
              <span className="profile-stat-label">Badges</span>
            </div>
          </div>
        </div>

        <DropdownMenuSeparator />

        <div className="p-2">
          <DropdownMenuItem asChild className="hover:bg-gradient-to-r hover:from-primary/5 hover:to-purple-500/5">
            <Link href="/profile" className="flex cursor-pointer">
              <User className="mr-3 h-4 w-4" />
              <span>My Profile</span>
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem asChild className="hover:bg-gradient-to-r hover:from-primary/5 hover:to-purple-500/5">
            <Link href="/resume" className="flex cursor-pointer">
              <FileText className="mr-3 h-4 w-4" />
              <span>My Resume</span>
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem asChild className="hover:bg-gradient-to-r hover:from-primary/5 hover:to-purple-500/5">
            <Link href="/submissions" className="flex cursor-pointer">
              <Code className="mr-3 h-4 w-4" />
              <span>My Submissions</span>
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem asChild className="hover:bg-gradient-to-r hover:from-primary/5 hover:to-purple-500/5">
            <Link href="/calendar" className="flex cursor-pointer">
              <Calendar className="mr-3 h-4 w-4" />
              <span>Activity Calendar</span>
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem asChild className="hover:bg-gradient-to-r hover:from-primary/5 hover:to-purple-500/5">
            <Link href="/achievements" className="flex cursor-pointer">
              <Award className="mr-3 h-4 w-4" />
              <span>Achievements</span>
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem asChild className="hover:bg-gradient-to-r hover:from-primary/5 hover:to-purple-500/5">
            <Link href="/study-plan" className="flex cursor-pointer">
              <GraduationCap className="mr-3 h-4 w-4" />
              <span>Study Plan</span>
            </Link>
          </DropdownMenuItem>
        </div>

        <DropdownMenuSeparator />

        <div className="p-2">
          <DropdownMenuItem asChild className="hover:bg-gradient-to-r hover:from-primary/5 hover:to-purple-500/5">
            <Link href="/settings" className="flex cursor-pointer">
              <Settings className="mr-3 h-4 w-4" />
              <span>Settings</span>
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem className="text-destructive focus:text-destructive hover:bg-gradient-to-r hover:from-red-500/5 hover:to-pink-500/5">
            <LogOut className="mr-3 h-4 w-4" />
            <span>Log out</span>
          </DropdownMenuItem>
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
